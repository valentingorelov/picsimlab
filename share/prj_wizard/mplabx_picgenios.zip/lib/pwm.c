/* ########################################################################

   PICsim - PIC simulator http://sourceforge.net/projects/picsim/

   ########################################################################

   Copyright (c) : 2015-2017  Luis Claudio Gamb�a Lopes

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   For e-mail suggestions :  lcgamboa@yahoo.com
   ######################################################################## */

#include <xc.h>

#include"config.h"

unsigned int mfac;

void PWM1_Init(unsigned int f) {
    unsigned int temp;
    //PWM Period = [(PR2) + 1] * 4 * TOSC *(TMR2 Prescale Value)
    //PWM Duty Cycle = (CCPRXL:CCPXCON<5:4>) *TOSC * (TMR2 Prescale Value)

    //desliga PWM
    CCP1CON = 0x00; //CCP disabled
    //TRISCbits.TRISC2=1; //desliga sa�das PWM

    PORTCbits.RC2 = 0; //deliga sa�das PWM

    CCPR1L = 0; //ou 255?

    //calculo TMR2
    T2CONbits.TMR2ON = 0;

    temp = (unsigned int) (_XTAL_FREQ / (f * 4l));

    if (temp < 256) {
        T2CONbits.T2CKPS = 0; //1
        PR2 = temp;
    } else if (temp / 4 < 256) {
        T2CONbits.T2CKPS = 1; //4
        PR2 = (temp + 2) / 4;
    } else {
        PR2 = (temp + 8) / 16;
        T2CONbits.T2CKPS = 2; //16
    }

#if !defined(_18F45K50) && !defined(_18F4520) && !defined(_16F1939) && !defined(_16F1789) && !defined(_18F47K40) 
    T2CONbits.TOUTPS = 0x00; //1-16
#else     
    T2CONbits.T2OUTPS = 0x00;
#endif


    mfac = (unsigned int) (((PR2 << 2) | 0x03) / 100);
}

void PWM1_Start(void) {

    TRISCbits.TRISC2 = 0; //liga sa�das PWM

    CCP1CON = 0x0C;

    T2CONbits.TMR2ON = 1;

    //espera PWM normalizar

#ifdef _18F47K40
    PIR4bits.TMR2IF = 0;
    while (PIR4bits.TMR2IF == 0);
    PIR4bits.TMR2IF = 0;
    while (PIR4bits.TMR2IF == 0);
#else    
    PIR1bits.TMR2IF = 0;
    while (PIR1bits.TMR2IF == 0);
    PIR1bits.TMR2IF = 0;
    while (PIR1bits.TMR2IF == 0);
#endif

}

void PWM1_Stop(void) {
    //desliga PWM
    CCP1CON = 0x00; //CCP disabled
    //T2CONbits.TMR2ON = 0;
}

void PWM1_Set_Duty(unsigned char d) {
    unsigned int temp;

    temp = (((unsigned long) (d)) * mfac);

    CCPR1L = (0x03FC & temp) >> 2;
    //CCP1CON = ((0x0003 & temp) << 4) | 0x0C;
}

#ifndef _18F4580

void PWM2_Init(unsigned int f) {

}

void PWM2_Start(void) {

    TRISCbits.TRISC1 = 0; //liga sa�das PWM
    CCP2CON = 0x0C;
}

void PWM2_Stop(void) {
    //desliga PWM
    CCP2CON = 0x00; //CCP disabled
    //T2CONbits.TMR2ON = 0;
}

void PWM2_Set_Duty(unsigned char d) {
    unsigned int temp;
    temp = (((unsigned long) (d)) * mfac);

    CCPR2L = (0x03FC & temp) >> 2;
    //CCP2CON = ((0x0003 & temp) << 4) | 0x0C;
}
#endif

